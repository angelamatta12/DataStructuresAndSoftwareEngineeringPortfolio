// EECS 370 SP 23 - Lab 2
// DO NOT MODIFY ANY OF THE CODE BELOW

#ifndef NUM_HIGH_BITS
#define NUM_HIGH_BITS

int numHighBits(int input);

#endif